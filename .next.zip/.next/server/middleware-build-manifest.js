globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/317e17b3e2d913c9.js",
    "static/chunks/236f7e5abd6f09ff.js",
    "static/chunks/060f0f7e93635401.js",
    "static/chunks/cc759f7c2413b7ff.js",
    "static/chunks/turbopack-c279206f7274b1aa.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];