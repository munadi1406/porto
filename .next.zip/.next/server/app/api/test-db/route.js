var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/test-db/route.js")
R.c("server/chunks/[root-of-the-server]__ef99e115._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/_next-internal_server_app_api_test-db_route_actions_c6c8244a.js")
R.m(55023)
module.exports=R.m(55023).exports
