var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/portfolio/route.js")
R.c("server/chunks/[root-of-the-server]__eaa1d1f0._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/_next-internal_server_app_api_portfolio_route_actions_9cd68082.js")
R.m(46541)
module.exports=R.m(46541).exports
