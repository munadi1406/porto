var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/portfolios/aggregate/route.js")
R.c("server/chunks/[root-of-the-server]__ea9d0105._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/_next-internal_server_app_api_portfolios_aggregate_route_actions_16e94158.js")
R.m(41122)
module.exports=R.m(41122).exports
