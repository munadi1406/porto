var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/portfolios/aggregate/history/route.js")
R.c("server/chunks/[root-of-the-server]__104e87e9._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/ce889_server_app_api_portfolios_aggregate_history_route_actions_66ac3ad6.js")
R.m(86832)
module.exports=R.m(86832).exports
