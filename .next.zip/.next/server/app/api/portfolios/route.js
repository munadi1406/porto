var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/portfolios/route.js")
R.c("server/chunks/[root-of-the-server]__6a935588._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/_next-internal_server_app_api_portfolios_route_actions_f9be477d.js")
R.m(69880)
module.exports=R.m(69880).exports
