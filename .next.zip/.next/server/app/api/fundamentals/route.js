var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/fundamentals/route.js")
R.c("server/chunks/[root-of-the-server]__a4d88749._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/_next-internal_server_app_api_fundamentals_route_actions_098fd3b9.js")
R.m(64315)
module.exports=R.m(64315).exports
