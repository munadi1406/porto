var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/sector/route.js")
R.c("server/chunks/[root-of-the-server]__3e230c0e._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/_next-internal_server_app_api_sector_route_actions_7b48cf77.js")
R.m(51432)
module.exports=R.m(51432).exports
