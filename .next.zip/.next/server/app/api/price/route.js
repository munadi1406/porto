var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/price/route.js")
R.c("server/chunks/[root-of-the-server]__fee1f393._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/_next-internal_server_app_api_price_route_actions_51b9e78d.js")
R.m(74759)
module.exports=R.m(74759).exports
