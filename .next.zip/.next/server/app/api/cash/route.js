var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/cash/route.js")
R.c("server/chunks/[root-of-the-server]__f380cf3b._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/_next-internal_server_app_api_cash_route_actions_9d1b6ed2.js")
R.m(75505)
module.exports=R.m(75505).exports
