var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/snapshots/route.js")
R.c("server/chunks/[root-of-the-server]__30d5d998._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/_next-internal_server_app_api_snapshots_route_actions_4981e0e9.js")
R.m(21199)
module.exports=R.m(21199).exports
