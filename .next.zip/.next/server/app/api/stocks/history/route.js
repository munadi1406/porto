var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/stocks/history/route.js")
R.c("server/chunks/[root-of-the-server]__0817c3a6._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/_next-internal_server_app_api_stocks_history_route_actions_ae08ac71.js")
R.m(37343)
module.exports=R.m(37343).exports
