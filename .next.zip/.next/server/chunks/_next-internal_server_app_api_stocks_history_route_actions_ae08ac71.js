module.exports=[22484,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_stocks_history_route_actions_ae08ac71.js.map