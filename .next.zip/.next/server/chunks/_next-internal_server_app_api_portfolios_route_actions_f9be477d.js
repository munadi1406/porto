module.exports=[21750,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_portfolios_route_actions_f9be477d.js.map