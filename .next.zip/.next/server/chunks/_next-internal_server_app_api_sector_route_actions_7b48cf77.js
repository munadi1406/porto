module.exports=[53232,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sector_route_actions_7b48cf77.js.map