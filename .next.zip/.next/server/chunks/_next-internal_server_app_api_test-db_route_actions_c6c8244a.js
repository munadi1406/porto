module.exports=[41932,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_test-db_route_actions_c6c8244a.js.map