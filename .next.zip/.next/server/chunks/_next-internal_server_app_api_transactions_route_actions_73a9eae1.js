module.exports=[29033,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_transactions_route_actions_73a9eae1.js.map