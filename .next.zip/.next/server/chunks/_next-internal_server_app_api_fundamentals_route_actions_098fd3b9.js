module.exports=[16292,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_fundamentals_route_actions_098fd3b9.js.map