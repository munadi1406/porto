module.exports=[51605,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_price_route_actions_51b9e78d.js.map