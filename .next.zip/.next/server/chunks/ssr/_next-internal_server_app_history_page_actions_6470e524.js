module.exports=[53964,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_history_page_actions_6470e524.js.map