module.exports=[96605,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_analysis_%5Bticker%5D_page_actions_184b97e0.js.map