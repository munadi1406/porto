module.exports=[27061,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_fundamentals_page_actions_0f93d746.js.map