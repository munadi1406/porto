module.exports=[15650,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_aggregate_page_actions_8a4f3620.js.map