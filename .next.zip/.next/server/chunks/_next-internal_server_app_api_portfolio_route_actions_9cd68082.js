module.exports=[17684,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_portfolio_route_actions_9cd68082.js.map