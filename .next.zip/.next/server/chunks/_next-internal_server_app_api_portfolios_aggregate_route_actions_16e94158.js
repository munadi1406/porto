module.exports=[34553,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_portfolios_aggregate_route_actions_16e94158.js.map